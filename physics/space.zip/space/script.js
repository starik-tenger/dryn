var screen=document.getElementById("screen");
var ctx=screen.getContext("2d");
screen.width = screen.height = 1000;

var screenB=document.getElementById("background");
var ctxB=screenB.getContext("2d");
screenB.width = screenB.height = 1000;

var screenG=document.getElementById("graphic");
var ctxG=screenG.getContext("2d");
screenG.width = screenG.height = 1000;

var output=document.getElementById("text");

ctx.clearRect(0,0,1000,1000);
var G=1;
var dt=0.0000001;
var objects=[];



class Object{
	constructor(x, y, m, sX, sY, color){
		this.x = x;
		this.y = y;
		this.xPrev = x;
		this.yPrev = y;
		this.m = m;
		this.fX = 0;
		this.fY = 0;
		this.sX = sX;
		this.sY = sY;
		this.color = color;
		this.index = 0;
		this.radius = Math.sqrt(Math.sqrt(this.m/800));
	}
	
	calculate(n){
		this.index = n;
		this.radius = (Math.sqrt(this.m/800000)*1);
		this.fX = 0;
		this.fY = 0;
		for(var i=0; i<objects.length; i++){
			var object = objects[i];
			var dx = object.x-this.x;
			var dy = object.y-this.y;
			var r = Math.sqrt(dx*dx + dy*dy);
			//text.innerHTML = r;
			if(r > 0){
			
			var m1 = this.m;
			var m2 = object.m;
			var sin  = dy/r;
			var cos = dx/r;
			var f = G*(m1*m2)/(r*r);
			//text.innerHTML = f;
			
			this.fX += f*cos;
			this.fY += f*sin;
			}
		}
		this.sX += this.fX/this.m * dt;
		this.sY += this.fY/this.m *dt;
		
	}
	
	move(){
		
		this.x += this.sX*dt;
		this.y += this.sY*dt;
	}
	
	save(){
		this.xPrev = this.x;
		this.yPrev = this.y;
	}
	
	//трах-тибидох
	join(){
		for(var i=0; i<objects.length; i++){
			var object = objects[i];
			var dx = object.x-this.x;
			var dy = object.y-this.y;
			var r = Math.sqrt(dx*dx + dy*dy);
			if(object != this && r<(this.radius+object.radius)){
				console.log("Join!", object.fX, object.fY)
				this.sX = (object.sX *object.m + this.sX *this.m)/(this.m+object.m);
				this.sX = (object.sY *object.m + this.sY *this.m)/(this.m+object.m);
				this.x = (this.x*this.m + object.x*object.m)/(this.m+object.m);
				this.y = (this.y*this.m + object.y*object.m)/(this.m+object.m);
				this.m += object.m;
				objects.splice(i, 1);
			}
		}
	}
	
	energy(){
		this.speed = pif(this.sX, this.sY);
		var Ep = 0;
		for(var i=0; i<objects.length; i++){
			var object = objects[i];
			var dx = object.x-this.x;
			var dy = object.y-this.y;
			var r = Math.sqrt(dx*dx + dy*dy);
			if(r <= 0)
				continue
			
			var m1 = this.m;
			var m2 = object.m;
			
			Ep += G*m1*m2/r
		}
		var Ek = this.m*this.speed*this.speed/2;
		return Ek-Ep;
		
	}
	
	draw(){
		ctx.beginPath();
		var r = 1+this.radius;
		ctx.arc(this.x, this.y, r, 0, 2*Math.PI, 0);
		ctx.fillStyle = this.color;
		ctx.fill();
	}
	
}

function setObject(x, y, m, speed, direction, color){
	var a = inRad(direction);
	var sX = speed*Math.cos(a);
	var sY = speed*Math.sin(a);
	objects.push(new Object(x, y, m, sX, sY, color));
}



//set objects--------------------------------------------------------------------------
//setObject(500, 500, 5000000000, 0, 0, "black");
setObject(250, 500, 5000000000, 2500, 270, "green");
setObject(750, 500, 5000000000, 2500, 90, "red");


for(var i=0; i<50; i++){
	var c = "rgb(" + random(0,255) +","+ random(0,255) +","+ random(0,255) +")";
	//setObject(random(0,1000), random(0,1000), normal(0,5000000000, 3), random(0,5000), random(0,360), c);
}
//--------------------------------------------------------------------------


function pif(a, b)
{
    return Math.sqrt(a*a+b*b);
}

function inRad(n){
    return n*Math.PI/180;
}

function random(min, max)
{
 return Math.floor(Math.random() * (max - min + 1)) + min;
}

function normal(a,b,n)
{
	var s=0;
	for(var i=0; i<n; i++)
	{
		s+=random(a,b);
	}
	s=Math.round(s/n);
	return s;
}

function drawWay()
{
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		drawLine(ctxB, object.xPrev, object.yPrev, object.x, object.y, object.color);
	}
}

function drawGraphic(){
	//var dx = objects[0].x - objects[1].x;
	//var dy = objects[0].y - objects[1].y;
	//var a = pif(dx, dy); 
	//console.log(a);
	var b = -energy/50000000000000000;
	ctxG.fillRect(time%1000, 500, 1, b);
	if(time%1000==0){
		ctxG.clearRect(0,0,1000,1000);
	}
}

function drawLine(c, x, y, x1, y1, color){
	c.beginPath();
	c.moveTo(x, y);
	c.lineTo(x1, y1);
	c.strokeStyle = color;
	c.fillStyle = color;
	c.stroke();
}

var energy = 0;

function calculateEnergy(){
	energy = 0;
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		energy += object.energy();
	}
	output.innerHTML = energy;
}

function step(){
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		object.calculate(i);
	}
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		object.move();
	}
	
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		object.join();
	}
	
}

ctx.globalAlpha = 0.8;
var time = 0;
function play()
{
	drawWay();
	
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		object.save();
	}
	for(var i=0; i<1000; i++){
		step();
	}
	ctx.clearRect(0,0,1000,1000);
	for(var i=0; i<objects.length; i++){
		var object = objects[i];
		object.draw();
	}
	calculateEnergy();
	drawGraphic();
	time++;
	setTimeout(play, 0);

}

play();